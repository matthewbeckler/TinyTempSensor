This kicad file archive was generated on 2011-10-06.
For more details, please visit https://github.com/matthewbeckler/TinyTempSensor
